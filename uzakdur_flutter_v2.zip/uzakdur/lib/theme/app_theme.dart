import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ── Renk paleti ──────────────────────────────────────────────────────────────
class AppColors {
  // Arka planlar
  static const bg = Color(0xFF0D0D0F);
  static const surface = Color(0xFF16161A);
  static const surfaceHigh = Color(0xFF1E1E24);
  static const border = Color(0xFF2A2A32);
  static const borderLight = Color(0xFF3A3A44);

  // Durum renkleri
  static const safe = Color(0xFF00C896);
  static const safeGlow = Color(0x2000C896);
  static const warning = Color(0xFFFFB020);
  static const warningGlow = Color(0x20FFB020);
  static const danger = Color(0xFFFF3B30);
  static const dangerGlow = Color(0x30FF3B30);
  static const dangerDeep = Color(0xFF2D0A0A);

  // Rol renkleri
  static const roleA = Color(0xFFFF5F57);   // Kırmızı — Uzaklaştırma
  static const roleAGlow = Color(0x25FF5F57);
  static const roleB = Color(0xFF4FACFE);   // Mavi — Korunan
  static const roleBGlow = Color(0x254FACFE);

  // Metin
  static const textPrimary = Color(0xFFF0F0F5);
  static const textSecondary = Color(0xFF9090A0);
  static const textMuted = Color(0xFF55555F);
  static const textDisabled = Color(0xFF3A3A44);
}

// ── Tipografi ─────────────────────────────────────────────────────────────────
class AppTypography {
  static TextStyle display(double size, Color color, {FontWeight weight = FontWeight.w800}) =>
      GoogleFonts.inter(fontSize: size, fontWeight: weight, color: color, height: 1.1);

  static TextStyle label(double size, Color color, {double spacing = 1.5}) =>
      GoogleFonts.inter(fontSize: size, fontWeight: FontWeight.w600, color: color, letterSpacing: spacing);

  static TextStyle body(double size, Color color) =>
      GoogleFonts.inter(fontSize: size, fontWeight: FontWeight.w400, color: color, height: 1.5);

  static TextStyle mono(double size, Color color) =>
      GoogleFonts.sourceCodePro(fontSize: size, color: color, height: 1.4);
}

// ── Gölge & gradient yardımcıları ────────────────────────────────────────────
class AppGlow {
  static List<BoxShadow> of(Color color, {double blur = 20, double spread = 0}) =>
      [BoxShadow(color: color.withOpacity(0.4), blurRadius: blur, spreadRadius: spread)];
}

// ── Tema ──────────────────────────────────────────────────────────────────────
ThemeData buildAppTheme() {
  return ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.roleA,
      secondary: AppColors.safe,
      surface: AppColors.surface,
    ),
    splashFactory: NoSplash.splashFactory,
    highlightColor: Colors.transparent,
  );
}
