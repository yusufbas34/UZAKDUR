import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:intl/intl.dart';
import '../services/location_service.dart';
import '../services/notification_service.dart';
import '../services/foreground_task_service.dart';
import '../theme/app_theme.dart';

// ── Olay log modeli ───────────────────────────────────────────────────────────
class LogEntry {
  final String time;
  final double distance;
  final bool isAlarm;
  LogEntry(this.time, this.distance, this.isAlarm);
}

// ── Ana ekran ─────────────────────────────────────────────────────────────────
class MonitorScreen extends StatefulWidget {
  final String role;
  final double threshold;

  const MonitorScreen({
    super.key,
    required this.role,
    required this.threshold,
  });

  @override
  State<MonitorScreen> createState() => _MonitorScreenState();
}

class _MonitorScreenState extends State<MonitorScreen>
    with WidgetsBindingObserver, TickerProviderStateMixin {
  // ── State ─────────────────────────────────────────────────────────────────
  late final String _role;
  late final String _otherRole;
  late final double _threshold;

  LocationData? _myLocation;
  LocationData? _otherLocation;
  double? _distance;
  bool _isAlarm = false;
  bool _isRunning = false;
  bool _otherOnline = false;
  String _statusText = 'GPS bekleniyor…';
  String? _errorText;

  final List<LogEntry> _log = [];
  final _fmt = DateFormat('HH:mm:ss');

  // ── Streams ───────────────────────────────────────────────────────────────
  StreamSubscription<Position>? _posSub;
  StreamSubscription? _otherLocSub;
  StreamSubscription? _otherStatusSub;
  Timer? _pollTimer;

  // ── Animasyonlar ──────────────────────────────────────────────────────────
  late AnimationController _alarmCtrl;
  late Animation<double> _alarmAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  // ── Harita ────────────────────────────────────────────────────────────────
  GoogleMapController? _mapCtrl;
  Set<Marker> _markers = {};
  Set<Circle> _circles = {};
  Set<Polyline> _polylines = {};
  bool _mapReady = false;
  bool _mapFollowsMe = true;

  // Google Maps karanlık tema için JSON string
  static const _darkMapStyle = '''[
    {"elementType":"geometry","stylers":[{"color":"#1a1a2e"}]},
    {"elementType":"labels.text.fill","stylers":[{"color":"#8888aa"}]},
    {"elementType":"labels.text.stroke","stylers":[{"color":"#1a1a2e"}]},
    {"featureType":"road","elementType":"geometry","stylers":[{"color":"#2a2a3e"}]},
    {"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#6666aa"}]},
    {"featureType":"water","elementType":"geometry","stylers":[{"color":"#0d0d1a"}]},
    {"featureType":"poi","stylers":[{"visibility":"off"}]},
    {"featureType":"transit","stylers":[{"visibility":"off"}]}
  ]''';

  @override
  void initState() {
    super.initState();
    _role = widget.role;
    _otherRole = _role == 'A' ? 'B' : 'A';
    _threshold = widget.threshold;

    // Alarm animasyonu (bg renk pulse)
    _alarmCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _alarmAnim = CurvedAnimation(parent: _alarmCtrl, curve: Curves.easeInOut);

    // Radar pulse animasyonu (harita üstündeki daire)
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    WidgetsBinding.instance.addObserver(this);
    ForegroundTaskService.init();
    _start();
  }

  // ── Servis başlat ─────────────────────────────────────────────────────────
  Future<void> _start() async {
    setState(() {
      _errorText = null;
      _statusText = 'Konum izni kontrol ediliyor…';
    });

    final result = await LocationService.requestPermissions();
    if (!mounted) return;

    switch (result) {
      case LocationPermissionResult.serviceDisabled:
        _setError('GPS kapalı. Lütfen konumu etkinleştir.');
        return;
      case LocationPermissionResult.denied:
        _setError('Konum izni reddedildi.');
        return;
      case LocationPermissionResult.deniedForever:
        _setError('Konum izni kalıcı reddedildi. Ayarlardan aç.');
        return;
      case LocationPermissionResult.granted:
        break;
    }

    setState(() {
      _isRunning = true;
      _statusText = 'Konum alınıyor…';
    });

    // Foreground servis başlat
    await ForegroundTaskService.start(role: _role, threshold: _threshold);
    await LocationService.setOnline(_role, true);

    // Kendi GPS akışı
    _posSub = LocationService.startLocationStream().listen(
      (pos) async {
        final loc = LocationData(
          lat: pos.latitude,
          lon: pos.longitude,
          timestamp: DateTime.now(),
        );
        if (!mounted) return;
        setState(() => _myLocation = loc);
        await LocationService.writeLocation(_role, pos.latitude, pos.longitude);
        _updateMap();
        _checkDistance();
      },
      onError: (e) => _setError('GPS hatası: $e'),
    );

    // Diğer cihazın konumunu dinle (Firebase realtime)
    _otherLocSub = LocationService.listenOtherLocation(_otherRole, (loc) {
      if (!mounted) return;
      setState(() => _otherLocation = loc);
      _updateMap();
      _checkDistance();
    });

    // Online durumu dinle
    _otherStatusSub = LocationService.listenOtherStatus(_otherRole, (online) {
      if (!mounted) return;
      setState(() => _otherOnline = online);
    });

    // Ek güvenlik: her 5 sn mesafeyi kontrol et
    _pollTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) => _checkDistance(),
    );
  }

  // ── Mesafe hesabı & alarm ─────────────────────────────────────────────────
  void _checkDistance() {
    if (_myLocation == null || _otherLocation == null) return;

    final d = LocationService.calculateDistance(
      _myLocation!.lat, _myLocation!.lon,
      _otherLocation!.lat, _otherLocation!.lon,
    );

    final isAlarm = d < _threshold;
    final now = _fmt.format(DateTime.now());

    if (!mounted) return;
    setState(() {
      _distance = d;
      _isAlarm = isAlarm;
      _statusText = isAlarm
          ? 'Yaklaşma tespit edildi!'
          : d < _threshold * 1.5
              ? 'Dikkat — Sınıra yaklaşıyor'
              : 'Güvenli mesafede';

      // Log: sadece durum değişimlerini kaydet
      if (_log.isEmpty || _log.first.isAlarm != isAlarm) {
        _log.insert(0, LogEntry(now, d, isAlarm));
        if (_log.length > 100) _log.removeLast();
      }
    });

    if (isAlarm) {
      if (!_alarmCtrl.isAnimating) _alarmCtrl.repeat(reverse: true);
      NotificationService.startAlarm(d);
      LocationService.writeAlarmLog(_role, d);
    } else {
      _alarmCtrl.stop();
      _alarmCtrl.reset();
      NotificationService.stopAlarm();
    }
  }

  // ── Harita güncelle ───────────────────────────────────────────────────────
  void _updateMap() {
    if (!_mapReady || _mapCtrl == null) return;

    final markers = <Marker>{};
    final circles = <Circle>{};
    final polylines = <Polyline>{};

    // Kendi marker
    if (_myLocation != null) {
      final pos = LatLng(_myLocation!.lat, _myLocation!.lon);
      markers.add(Marker(
        markerId: const MarkerId('me'),
        position: pos,
        icon: BitmapDescriptor.defaultMarkerWithHue(
          _role == 'A' ? BitmapDescriptor.hueRed : BitmapDescriptor.hueAzure,
        ),
        infoWindow: InfoWindow(title: 'Cihaz $_role (Ben)'),
        zIndex: 2,
      ));

      // Eşik dairesi
      circles.add(Circle(
        circleId: const CircleId('threshold'),
        center: pos,
        radius: _threshold,
        fillColor: (_isAlarm ? AppColors.danger : AppColors.safe).withOpacity(0.08),
        strokeColor: (_isAlarm ? AppColors.danger : AppColors.safe).withOpacity(0.4),
        strokeWidth: 1,
      ));

      // Kamera takibi
      if (_mapFollowsMe) {
        _mapCtrl!.animateCamera(
          CameraUpdate.newLatLng(pos),
        );
      }
    }

    // Diğer cihaz marker
    if (_otherLocation != null) {
      final pos = LatLng(_otherLocation!.lat, _otherLocation!.lon);
      markers.add(Marker(
        markerId: const MarkerId('other'),
        position: pos,
        icon: BitmapDescriptor.defaultMarkerWithHue(
          _role == 'A' ? BitmapDescriptor.hueAzure : BitmapDescriptor.hueRed,
        ),
        infoWindow: InfoWindow(title: 'Cihaz $_otherRole'),
        zIndex: 1,
      ));
    }

    // İki cihaz arası çizgi
    if (_myLocation != null && _otherLocation != null) {
      polylines.add(Polyline(
        polylineId: const PolylineId('connection'),
        points: [
          LatLng(_myLocation!.lat, _myLocation!.lon),
          LatLng(_otherLocation!.lat, _otherLocation!.lon),
        ],
        color: (_isAlarm ? AppColors.danger : AppColors.safe).withOpacity(0.6),
        width: 2,
        patterns: [PatternItem.dash(12), PatternItem.gap(6)],
      ));

      // İki cihazı da görecek kamera
      if (!_mapFollowsMe) {
        _mapCtrl!.animateCamera(
          CameraUpdate.newLatLngBounds(
            LatLngBounds(
              southwest: LatLng(
                [_myLocation!.lat, _otherLocation!.lat].reduce((a, b) => a < b ? a : b) - 0.001,
                [_myLocation!.lon, _otherLocation!.lon].reduce((a, b) => a < b ? a : b) - 0.001,
              ),
              northeast: LatLng(
                [_myLocation!.lat, _otherLocation!.lat].reduce((a, b) => a > b ? a : b) + 0.001,
                [_myLocation!.lon, _otherLocation!.lon].reduce((a, b) => a > b ? a : b) + 0.001,
              ),
            ),
            60,
          ),
        );
      }
    }

    if (!mounted) return;
    setState(() {
      _markers = markers;
      _circles = circles;
      _polylines = polylines;
    });
  }

  // ── Servis durdur ─────────────────────────────────────────────────────────
  Future<void> _stop() async {
    _posSub?.cancel();
    _otherLocSub?.cancel();
    _otherStatusSub?.cancel();
    _pollTimer?.cancel();
    _alarmCtrl.stop();
    _alarmCtrl.reset();
    NotificationService.stopAlarm();

    // Firebase/foreground async işlemler (dispose'dan sonra mounted check yok)
    ForegroundTaskService.stop().ignore();
    LocationService.setOnline(_role, false).ignore();

    if (!mounted) return;
    setState(() {
      _isRunning = false;
      _isAlarm = false;
      _statusText = 'Durduruldu';
    });
  }

  void _setError(String msg) {
    if (!mounted) return;
    setState(() {
      _errorText = msg;
      _isRunning = false;
      _statusText = 'Hata';
    });
  }

  // ── Lifecycle ─────────────────────────────────────────────────────────────
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.detached) {
      _stop();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _posSub?.cancel();
    _otherLocSub?.cancel();
    _otherStatusSub?.cancel();
    _pollTimer?.cancel();
    _alarmCtrl.dispose();
    _pulseCtrl.dispose();
    _mapCtrl?.dispose();
    // Fire-and-forget async ops (safe after dispose)
    NotificationService.stopAlarm().ignore();
    ForegroundTaskService.stop().ignore();
    LocationService.setOnline(_role, false).ignore();
    super.dispose();
  }

  // ── Yardımcılar ───────────────────────────────────────────────────────────
  Color get _roleColor => _role == 'A' ? AppColors.roleA : AppColors.roleB;
  Color get _statusColor {
    if (_isAlarm) return AppColors.danger;
    if (_distance != null && _distance! < _threshold * 1.5) return AppColors.warning;
    return AppColors.safe;
  }

  // ════════════════════════════════════════════════════════════════════════════
  // BUILD
  // ════════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return WithForegroundTask(
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: Scaffold(
          backgroundColor: AppColors.bg,
          body: AnimatedBuilder(
            animation: _alarmAnim,
            builder: (_, child) {
              return ColoredBox(
                color: _isAlarm
                    ? Color.lerp(AppColors.bg, AppColors.dangerDeep, _alarmAnim.value)!
                    : AppColors.bg,
                child: child,
              );
            },
            child: SafeArea(
              child: Column(
                children: [
                  _buildTopBar(),
                  Expanded(
                    child: _errorText != null
                        ? _buildErrorState()
                        : Column(
                            children: [
                              _buildMapSection(),
                              _buildBottomPanel(),
                            ],
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Top bar ───────────────────────────────────────────────────────────────
  Widget _buildTopBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.border, width: 0.5)),
      ),
      child: Row(
        children: [
          // Geri butonu
          GestureDetector(
            onTap: () async {
              await _stop();
              if (mounted) Navigator.pop(context);
            },
            child: Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.border),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: AppColors.textSecondary, size: 16),
            ),
          ),
          const SizedBox(width: 14),

          // Rol etiketi
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _roleColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _roleColor.withOpacity(0.3)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  _role == 'A'
                      ? Icons.person_pin_circle_rounded
                      : Icons.shield_rounded,
                  color: _roleColor,
                  size: 14,
                ),
                const SizedBox(width: 6),
                Text(
                  _role == 'A' ? 'Uzaklaştırma — A' : 'Korunan — B',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: _roleColor,
                  ),
                ),
              ],
            ),
          ),

          const Spacer(),

          // Online göstergeler
          _OnlineDot(
            label: 'Ben',
            online: _isRunning,
            color: _roleColor,
          ),
          const SizedBox(width: 10),
          _OnlineDot(
            label: 'Cihaz $_otherRole',
            online: _otherOnline,
            color: _role == 'A' ? AppColors.roleB : AppColors.roleA,
          ),
        ],
      ),
    );
  }

  // ── Harita bölümü ─────────────────────────────────────────────────────────
  Widget _buildMapSection() {
    return Expanded(
      flex: 5,
      child: Stack(
        children: [
          // Google Maps
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: _myLocation != null
                  ? LatLng(_myLocation!.lat, _myLocation!.lon)
                  : const LatLng(41.0082, 28.9784), // İstanbul default
              zoom: 16,
            ),
            markers: _markers,
            circles: _circles,
            polylines: _polylines,
            mapType: MapType.normal,
            myLocationEnabled: false, // Kendi marker'ımızı kendimiz koyuyoruz
            compassEnabled: false,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            buildingsEnabled: true,
            onMapCreated: (ctrl) {
              _mapCtrl = ctrl;
              ctrl.setMapStyle(_darkMapStyle);
              setState(() => _mapReady = true);
              _updateMap();
            },
            onCameraMove: (_) {
              // Kullanıcı haritayı kaydırınca takip modunu kapat
              if (_mapFollowsMe) {
                setState(() => _mapFollowsMe = false);
              }
            },
          ),

          // Sağ üst harita kontrolleri
          Positioned(
            top: 12,
            right: 12,
            child: Column(
              children: [
                _MapButton(
                  icon: _mapFollowsMe
                      ? Icons.my_location_rounded
                      : Icons.location_searching_rounded,
                  active: _mapFollowsMe,
                  color: _roleColor,
                  onTap: () {
                    setState(() => _mapFollowsMe = !_mapFollowsMe);
                    _updateMap();
                  },
                  tooltip: 'Konuma odaklan',
                ),
                const SizedBox(height: 8),
                _MapButton(
                  icon: Icons.fit_screen_rounded,
                  active: false,
                  color: AppColors.textSecondary,
                  onTap: () {
                    setState(() => _mapFollowsMe = false);
                    _updateMap();
                  },
                  tooltip: 'İkisini de göster',
                ),
              ],
            ),
          ),

          // Sol üst mesafe göstergesi (harita üstünde yüzen kart)
          Positioned(
            top: 12,
            left: 12,
            child: _FloatingDistanceCard(
              distance: _distance,
              threshold: _threshold,
              isAlarm: _isAlarm,
              statusColor: _statusColor,
            ),
          ),

          // Alarm overlay
          if (_isAlarm)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: AnimatedBuilder(
                animation: _alarmAnim,
                builder: (_, __) => Container(
                  height: 4,
                  color: AppColors.danger.withOpacity(0.6 + 0.4 * _alarmAnim.value),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ── Alt panel ─────────────────────────────────────────────────────────────
  Widget _buildBottomPanel() {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.bg,
        border: Border(top: BorderSide(color: AppColors.border, width: 0.5)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Status bar
          _buildStatusBar(),
          // Alarm butonu veya log
          _buildActionArea(),
        ],
      ),
    );
  }

  Widget _buildStatusBar() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        color: _isAlarm
            ? AppColors.danger.withOpacity(0.1)
            : AppColors.surface,
        border: Border(
          bottom: BorderSide(color: AppColors.border, width: 0.5),
          left: BorderSide(
            color: _statusColor,
            width: 3,
          ),
        ),
      ),
      child: Row(
        children: [
          // Durum ikonu
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: _statusColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              _isAlarm
                  ? Icons.warning_rounded
                  : _distance != null && _distance! < _threshold * 1.5
                      ? Icons.remove_red_eye_rounded
                      : Icons.check_circle_rounded,
              color: _statusColor,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _statusText,
                  style: GoogleFonts.inter(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: _isAlarm ? AppColors.danger : AppColors.textPrimary,
                  ),
                ),
                if (_isRunning)
                  Text(
                    'Eşik: ${_threshold.round()}m  •  5 sn\'de bir güncelleniyor',
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      color: AppColors.textMuted,
                    ),
                  ),
              ],
            ),
          ),
          // Servis durdur / başlat
          GestureDetector(
            onTap: _isRunning ? _stop : _start,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: _isRunning
                    ? AppColors.surface
                    : AppColors.safe.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: _isRunning
                      ? AppColors.border
                      : AppColors.safe.withOpacity(0.4),
                ),
              ),
              child: Text(
                _isRunning ? 'Durdur' : 'Başlat',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: _isRunning ? AppColors.textMuted : AppColors.safe,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionArea() {
    if (_isAlarm) {
      return GestureDetector(
        onTap: () {
          NotificationService.stopAlarm();
          _alarmCtrl.stop();
          _alarmCtrl.reset();
          setState(() => _isAlarm = false);
        },
        child: AnimatedBuilder(
          animation: _alarmAnim,
          builder: (_, __) => Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 18),
            color: Color.lerp(
                const Color(0xFFCC0000), AppColors.danger, _alarmAnim.value),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.volume_off_rounded,
                    color: Colors.white, size: 20),
                const SizedBox(width: 10),
                Text(
                  'ALARMI DURDUR',
                  style: GoogleFonts.inter(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return _buildLogSection();
  }

  Widget _buildLogSection() {
    return Container(
      height: 140,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'OLAY GEÇMİŞİ',
                style: GoogleFonts.inter(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textMuted,
                  letterSpacing: 2,
                ),
              ),
              const Spacer(),
              if (_log.isNotEmpty)
                Text(
                  '${_log.length} kayıt',
                  style: GoogleFonts.inter(
                    fontSize: 10,
                    color: AppColors.textDisabled,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _log.isEmpty
                ? Center(
                    child: Text(
                      'Henüz olay yok — GPS bağlandıktan sonra kayıt başlar',
                      textAlign: TextAlign.center,
                      style: GoogleFonts.inter(
                        fontSize: 11,
                        color: AppColors.textDisabled,
                      ),
                    ),
                  )
                : ListView.builder(
                    itemCount: _log.length,
                    itemBuilder: (_, i) {
                      final e = _log[i];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(
                          children: [
                            Container(
                              width: 6,
                              height: 6,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: e.isAlarm ? AppColors.danger : AppColors.safe,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              e.time,
                              style: GoogleFonts.sourceCodePro(
                                fontSize: 10,
                                color: AppColors.textMuted,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              '${e.distance.round()}m',
                              style: GoogleFonts.sourceCodePro(
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                color: e.isAlarm ? AppColors.danger : AppColors.safe,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              e.isAlarm ? '⚠ Alarm' : '✓ Güvenli',
                              style: GoogleFonts.inter(
                                fontSize: 10,
                                color: e.isAlarm ? AppColors.danger : AppColors.safe,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // ── Hata ekranı ───────────────────────────────────────────────────────────
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: AppColors.danger.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.location_off_rounded,
                  color: AppColors.danger, size: 32),
            ),
            const SizedBox(height: 20),
            Text(
              'Konum Hatası',
              style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _errorText ?? '',
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(
                fontSize: 13,
                color: AppColors.textSecondary,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 28),
            GestureDetector(
              onTap: _start,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                decoration: BoxDecoration(
                  color: _roleColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _roleColor.withOpacity(0.4)),
                ),
                child: Text(
                  'Tekrar Dene',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: _roleColor,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Alt widget'lar ────────────────────────────────────────────────────────────

class _OnlineDot extends StatelessWidget {
  final String label;
  final bool online;
  final Color color;

  const _OnlineDot({
    required this.label,
    required this.online,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 400),
          width: 7,
          height: 7,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: online ? color : AppColors.textDisabled,
            boxShadow: online
                ? [BoxShadow(color: color.withOpacity(0.5), blurRadius: 6)]
                : [],
          ),
        ),
        const SizedBox(width: 5),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 10,
            color: online ? AppColors.textSecondary : AppColors.textDisabled,
          ),
        ),
      ],
    );
  }
}

class _FloatingDistanceCard extends StatelessWidget {
  final double? distance;
  final double threshold;
  final bool isAlarm;
  final Color statusColor;

  const _FloatingDistanceCard({
    required this.distance,
    required this.threshold,
    required this.isAlarm,
    required this.statusColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.bg.withOpacity(0.92),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isAlarm ? AppColors.danger.withOpacity(0.5) : AppColors.border,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'MESAFE',
            style: GoogleFonts.inter(
              fontSize: 9,
              fontWeight: FontWeight.w700,
              color: AppColors.textMuted,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                distance != null ? '${distance!.round()}' : '—',
                style: GoogleFonts.inter(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: statusColor,
                  height: 1,
                ),
              ),
              const SizedBox(width: 4),
              Padding(
                padding: const EdgeInsets.only(bottom: 2),
                child: Text(
                  'm',
                  style: GoogleFonts.inter(
                    fontSize: 13,
                    color: AppColors.textMuted,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            'Eşik: ${threshold.round()}m',
            style: GoogleFonts.inter(
              fontSize: 10,
              color: AppColors.textMuted,
            ),
          ),
        ],
      ),
    );
  }
}

class _MapButton extends StatelessWidget {
  final IconData icon;
  final bool active;
  final Color color;
  final VoidCallback onTap;
  final String tooltip;

  const _MapButton({
    required this.icon,
    required this.active,
    required this.color,
    required this.onTap,
    required this.tooltip,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Tooltip(
        message: tooltip,
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: active ? color.withOpacity(0.15) : AppColors.bg.withOpacity(0.92),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: active ? color.withOpacity(0.5) : AppColors.border,
            ),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 8),
            ],
          ),
          child: Icon(icon, color: active ? color : AppColors.textSecondary, size: 18),
        ),
      ),
    );
  }
}
