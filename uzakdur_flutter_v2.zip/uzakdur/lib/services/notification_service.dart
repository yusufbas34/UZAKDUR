import 'package:flutter/material.dart' show Color, Colors;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:vibration/vibration.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _alarming = false;

  // ── Başlat ────────────────────────────────────────────────────────────────
  static Future<void> init() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: androidSettings));

    // Alarm kanalı (yüksek öncelik)
    await _createChannel(
      id: 'uzakdur_alarm',
      name: 'UZAKDUR Alarm',
      desc: 'Yaklaşma uyarısı — yüksek öncelik',
      importance: Importance.max,
      vibration: true,
    );

    // Durum kanalı (düşük öncelik — foreground servis)
    await _createChannel(
      id: 'uzakdur_status',
      name: 'UZAKDUR Servis',
      desc: 'Arka plan konum servisi',
      importance: Importance.low,
      vibration: false,
    );
  }

  static Future<void> _createChannel({
    required String id,
    required String name,
    required String desc,
    required Importance importance,
    required bool vibration,
  }) async {
    final channel = AndroidNotificationChannel(
      id, name,
      description: desc,
      importance: importance,
      enableVibration: vibration,
      playSound: importance == Importance.max,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  // ── Alarm başlat ──────────────────────────────────────────────────────────
  static Future<void> startAlarm(double distance) async {
    if (_alarming) return;
    _alarming = true;

    // Tam ekran bildirim
    const details = AndroidNotificationDetails(
      'uzakdur_alarm',
      'UZAKDUR Alarm',
      channelDescription: 'Yaklaşma uyarısı',
      importance: Importance.max,
      priority: Priority.max,
      fullScreenIntent: true,
      ongoing: true,
      autoCancel: false,
      color: Color(0xFFFF3B30),
      ledColor: Color(0xFFFF3B30),
      ledOnMs: 200,
      ledOffMs: 100,
      category: AndroidNotificationCategory.alarm,
    );

    await _plugin.show(
      101,
      '⚠️  YAKLAŞMA ALGILANDI',
      'Mesafe: ${distance.round()} metre — Uzaklaşın!',
      const NotificationDetails(android: details),
    );

    // Titreşim
    if (await Vibration.hasVibrator() ?? false) {
      Vibration.vibrate(
        pattern: [0, 600, 150, 600, 150, 900],
        repeat: 0,
      );
    }
  }

  // ── Alarm durdur ──────────────────────────────────────────────────────────
  static Future<void> stopAlarm() async {
    if (!_alarming) return;
    _alarming = false;
    await _plugin.cancel(101);
    Vibration.cancel();
  }

  static bool get isAlarming => _alarming;

  // ── Foreground servis bildirimi ───────────────────────────────────────────
  static Future<void> showStatus(String title, String body) async {
    const details = AndroidNotificationDetails(
      'uzakdur_status',
      'UZAKDUR Servis',
      channelDescription: 'Arka plan konum servisi',
      importance: Importance.low,
      priority: Priority.low,
      ongoing: true,
      autoCancel: false,
      showWhen: false,
    );
    await _plugin.show(
      102, title, body,
      const NotificationDetails(android: details),
    );
  }

  static Future<void> cancelStatus() async => _plugin.cancel(102);
}
