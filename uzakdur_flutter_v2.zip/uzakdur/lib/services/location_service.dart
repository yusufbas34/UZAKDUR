import 'dart:async';
import 'dart:math';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_database/firebase_database.dart';

// ── Veri modeli ───────────────────────────────────────────────────────────────
class LocationData {
  final double lat;
  final double lon;
  final DateTime timestamp;

  const LocationData({
    required this.lat,
    required this.lon,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
        'lat': lat,
        'lon': lon,
        'ts': timestamp.millisecondsSinceEpoch,
      };

  factory LocationData.fromMap(Map<dynamic, dynamic> map) => LocationData(
        lat: (map['lat'] as num).toDouble(),
        lon: (map['lon'] as num).toDouble(),
        timestamp: DateTime.fromMillisecondsSinceEpoch((map['ts'] as num).toInt()),
      );
}

// ── Servis ────────────────────────────────────────────────────────────────────
class LocationService {
  static final DatabaseReference _db = FirebaseDatabase.instance.ref();

  // ── İzin kontrolü ─────────────────────────────────────────────────────────
  static Future<LocationPermissionResult> requestPermissions() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return LocationPermissionResult.serviceDisabled;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return LocationPermissionResult.denied;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return LocationPermissionResult.deniedForever;
    }
    return LocationPermissionResult.granted;
  }

  // ── Firebase yazma ────────────────────────────────────────────────────────
  static Future<void> writeLocation(String role, double lat, double lon) async {
    await _db.child('locations/$role').set({
      'lat': lat,
      'lon': lon,
      'ts': DateTime.now().millisecondsSinceEpoch,
    });
  }

  static Future<void> setOnline(String role, bool online) async {
    await _db.child('status/$role').set({
      'online': online,
      'ts': DateTime.now().millisecondsSinceEpoch,
    });
  }

  static Future<void> writeAlarmLog(String role, double distance) async {
    await _db.child('alarm_log').push().set({
      'role': role,
      'distance': distance.round(),
      'ts': DateTime.now().millisecondsSinceEpoch,
    });
  }

  // ── Firebase dinleme ──────────────────────────────────────────────────────
  static StreamSubscription<DatabaseEvent> listenOtherLocation(
    String otherRole,
    void Function(LocationData) onData,
  ) {
    return _db.child('locations/$otherRole').onValue.listen((event) {
      final val = event.snapshot.value;
      if (val == null) return;
      try {
        onData(LocationData.fromMap(val as Map));
      } catch (_) {}
    });
  }

  static StreamSubscription<DatabaseEvent> listenOtherStatus(
    String otherRole,
    void Function(bool) onData,
  ) {
    return _db.child('status/$otherRole').onValue.listen((event) {
      final val = event.snapshot.value;
      if (val == null) {
        onData(false);
        return;
      }
      try {
        final map = val as Map;
        onData(map['online'] == true);
      } catch (_) {
        onData(false);
      }
    });
  }

  // ── GPS akışı ─────────────────────────────────────────────────────────────
  static Stream<Position> startLocationStream() {
    return Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 3, // 3m'den az harekette güncelleme
      ),
    );
  }

  // ── Haversine mesafe hesabı (metre) ───────────────────────────────────────
  static double calculateDistance(
    double lat1, double lon1,
    double lat2, double lon2,
  ) {
    const R = 6371000.0;
    final dLat = _rad(lat2 - lat1);
    final dLon = _rad(lon2 - lon1);
    final a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_rad(lat1)) * cos(_rad(lat2)) * sin(dLon / 2) * sin(dLon / 2);
    return R * 2 * atan2(sqrt(a), sqrt(1 - a));
  }

  static double _rad(double deg) => deg * pi / 180;
}

enum LocationPermissionResult { granted, denied, deniedForever, serviceDisabled }
