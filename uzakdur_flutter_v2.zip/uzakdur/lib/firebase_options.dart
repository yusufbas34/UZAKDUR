// ╔══════════════════════════════════════════════════════════════════════╗
// ║  Bu dosyayı elle doldurma — flutterfire CLI otomatik yapar:         ║
// ║                                                                      ║
// ║  1) firebase.google.com → Proje oluştur                             ║
// ║  2) Android ekle → paket: com.uzakdur.app                           ║
// ║  3) google-services.json → android/app/ klasörüne koy               ║
// ║  4) Terminal:                                                        ║
// ║       dart pub global activate flutterfire_cli                      ║
// ║       flutterfire configure                                          ║
// ║  5) Bu dosya otomatik dolar, aşağıyı silmen gerekmez                ║
// ╚══════════════════════════════════════════════════════════════════════╝

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError(
            'Bu platform için FirebaseOptions tanımlı değil.');
    }
  }

  // ↓ flutterfire configure çalıştırınca burası otomatik dolar ↓
  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'BURAYA_API_KEY',
    appId: 'BURAYA_APP_ID',
    messagingSenderId: 'BURAYA_SENDER_ID',
    projectId: 'BURAYA_PROJECT_ID',
    databaseURL: 'https://BURAYA_PROJECT_ID-default-rtdb.firebaseio.com',
    storageBucket: 'BURAYA_PROJECT_ID.appspot.com',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'BURAYA_API_KEY',
    appId: 'BURAYA_APP_ID',
    messagingSenderId: 'BURAYA_SENDER_ID',
    projectId: 'BURAYA_PROJECT_ID',
    databaseURL: 'https://BURAYA_PROJECT_ID-default-rtdb.firebaseio.com',
    storageBucket: 'BURAYA_PROJECT_ID.appspot.com',
    authDomain: 'BURAYA_PROJECT_ID.firebaseapp.com',
  );
}
