# UZAKDUR v2.0 — Yaklaşma Engel Sistemi
## Flutter + Firebase + Google Maps

---

## 📁 PROJE YAPISI

```
uzakdur/
├── lib/
│   ├── main.dart                           # Giriş noktası
│   ├── firebase_options.dart               # Firebase config (flutterfire doldurur)
│   ├── theme/
│   │   └── app_theme.dart                  # Renk sistemi, tipografi
│   ├── screens/
│   │   ├── home_screen.dart                # Rol seçimi + eşik ayarı
│   │   └── monitor_screen.dart             # Harita + alarm + log ekranı
│   └── services/
│       ├── location_service.dart           # GPS + Firebase + Haversine
│       ├── notification_service.dart       # Alarm + titreşim + bildirim
│       └── foreground_task_service.dart    # Arka plan GPS servisi
├── android/
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/main/AndroidManifest.xml    # İzinler + Maps API Key
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
├── firebase_rules.json                      # Database güvenlik kuralları
└── pubspec.yaml
```

---

## 🚀 KURULUM ADIMLARI

### 1. Flutter SDK
```bash
flutter --version   # 3.x olmalı
flutter doctor      # Tüm yeşil olmalı
```

### 2. Firebase Projesi
1. https://console.firebase.google.com → **Yeni Proje** oluştur
2. Sol menü → **Realtime Database** → Oluştur → **Test modu** seç
3. Sol menü → **Proje Ayarları** → **Android uygulaması ekle**
   - Paket adı: `com.uzakdur.app`
   - `google-services.json` indir → `android/app/` klasörüne koy
4. Firebase Console → Realtime Database → **Kurallar** → `firebase_rules.json` içeriğini yapıştır → **Yayınla**

### 3. FlutterFire CLI (firebase_options.dart'ı doldurur)
```bash
dart pub global activate flutterfire_cli
flutterfire configure --project=PROJE_ID_BURAYA
```

### 4. Google Maps API Key
1. https://console.cloud.google.com → Sol menü → **APIs & Services** → **Library**
2. "Maps SDK for Android" → **Enable**
3. **Credentials** → **Create Credentials** → **API Key**
4. API Key → **Restrict Key**:
   - Application restrictions: Android apps
   - Package: `com.uzakdur.app`
   - SHA-1: `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android`
5. `android/app/src/main/AndroidManifest.xml` → `YOUR_GOOGLE_MAPS_API_KEY` yerine key'i gir

### 5. Bağımlılıkları yükle
```bash
flutter pub get
```

### 6. APK Derle & Yükle
```bash
# Bağlı cihaza doğrudan yükle:
flutter run

# Debug APK:
flutter build apk --debug

# Release APK:
flutter build apk --release

# APK çıktısı:
# build/app/outputs/flutter-apk/app-release.apk
```

---

## 📱 KULLANIM

1. **A telefonu** → "Cihaz A — Uzaklaştırma" seç
2. **B telefonu** → "Cihaz B — Korunan" seç
3. Her iki telefon da internete bağlı olsun
4. GPS ve bildirim izinlerini ver
5. **Pil optimizasyonunu kapat** (çok önemli!)
6. İzle — 100m altında alarm devreye girer

---

## ⚙️ TEKNİK DETAYLAR

| Özellik | Değer |
|---------|-------|
| GPS güncelleme filtresi | Her 3 metre |
| Firebase polling | Realtime (anlık) + 5sn fallback |
| Mesafe algoritması | Haversine (WGS84) |
| Arka plan | Android Foreground Service |
| Alarm | Titreşim + Tam ekran bildirim + Ses |
| Harita | Google Maps SDK (karanlık tema) |
| Min Android | API 23 (Android 6.0) |

---

## 🔋 PİL OPTİMİZASYONU

Android arka plan GPS'i agresif şekilde kısıtlar:

**Ayarlar → Uygulamalar → UZAKDUR → Pil → "Kısıtlama yok"**

Veya uygulama ilk açılışta otomatik izin ister, **"İzin Ver"** de.

---

## 📡 FIREBASE VERİ YAPISI

```
/locations/A  → { lat, lon, ts }
/locations/B  → { lat, lon, ts }
/status/A     → { online: true, ts }
/status/B     → { online: true, ts }
/alarm_log    → { role, distance, ts }[]
```

---

## 🔜 SONRAKİ GELİŞTİRMELER

- [ ] Firebase Authentication (güvenli erişim)
- [ ] SMS / otomatik arama (Twilio)
- [ ] Çoklu kişi desteği
- [ ] iOS desteği
- [ ] Mahkeme kayıtları için log export
- [ ] Push notification (arka plan bildirimi FCM ile)
